const expenseName = document.getElementById("expense-name");
const expenseAmount = document.getElementById("expense-amount");
const expenseCategory = document.getElementById("categories");
const expenseDate = document.querySelector("input[type='date']");
const addButton = document.getElementById("add-button");
const expenseList = document.querySelector(".expense-list");

addButton.addEventListener("click", function () {
    const name = expenseName.value;
    const amount = expenseAmount.value;
    const category = expenseCategory.value;
    const date = expenseDate.value;

    if (name === "" || amount === "" || category === "" || date === "") {
        alert("Please fill out all the fields!");
        return;
    }

    if (amount <= 0) {
        alert("Amount must be a positive number!");
        return;
    }

    const listItem = document.createElement("li");

    listItem.innerHTML = `
    <span class="log-name">${name}</span>
        <span class="log-amount">₹${amount}</span>
        <span class="log-categories">${category}</span>
        <span class="log-date">${date}</span>
        <div class="button-group">
            <button class="edit-btn">Edit</button>
            <button class="delete-btn">Delete</button>
        </div>
    `;

    expenseList.appendChild(listItem);

    // for delete and edit button functionality
    listItem.querySelector(".delete-btn").addEventListener("click", function () {
        listItem.remove();
        updateTotal();  // Update total after deleting an expense

    });

    listItem.querySelector(".edit-btn").addEventListener("click", function () {
        editExpense(listItem);
    });

    // save to local storage
    saveExpense(name, amount, category, date);
    // Clear input fields
    expenseName.value = "";
    expenseAmount.value = "";
    expenseCategory.value = "";
    expenseDate.value = "";
    updateTotal();  // Update total after adding an expense


});

function editExpense(listItem){
    const name = listItem.querySelector(".log-name").textContent;
    const amount = listItem.querySelector(".log-amount").textContent.replace("₹", "");
    const category = listItem.querySelector(".log-categories").textContent;
    const date = listItem.querySelector(".log-date").textContent;

     // Fill input fields with existing values
     expenseName.value = name;
     expenseAmount.value = amount;
     expenseCategory.value = category;
     expenseDate.value = date;
 
     // Remove the old entry
     listItem.remove();
 
     // Update Local Storage
     removeExpense(name, amount, category, date);
}



function saveExpense(name, amount, category, date) {
    let expenses = JSON.parse(localStorage.getItem("expenses")) || [];
    expenses.push({ name, amount, category, date });
    localStorage.setItem("expenses", JSON.stringify(expenses));
}

function removeExpense(name, amount, category, date) {
    let expenses = JSON.parse(localStorage.getItem("expenses")) || [];
    expenses = expenses.filter(exp => !(exp.name === name && exp.amount === amount && exp.category === category && exp.date === date));
    localStorage.setItem("expenses", JSON.stringify(expenses));
}

window.addEventListener("load", function () {
    let expenses = JSON.parse(localStorage.getItem("expenses")) || [];
    expenses.forEach(exp => {
        const listItem = document.createElement("li");
        listItem.innerHTML = `
            <span class="log-name">${exp.name}</span>
            <span class="log-amount">₹${exp.amount}</span>
            <span class="log-categories">${exp.category}</span>
            <span class="log-date">${exp.date}</span>
            <div class="button-group">
                <button class="edit-btn">Edit</button>
                <button class="delete-btn">Delete</button>
            </div>
        `;

        expenseList.appendChild(listItem);

        listItem.querySelector(".delete-btn").addEventListener("click", function () {
            listItem.remove();
            removeExpense(exp.name, exp.amount, exp.category, exp.date);
        });

        listItem.querySelector(".edit-btn").addEventListener("click", function () {
            editExpense(listItem);
        });
    });
    updateTotal(); // Display total when the page loads

});

const totalAmountDisplay = document.getElementById("total-amount");
function updateTotal() {
    let expenses = JSON.parse(localStorage.getItem("expenses")) || [];
    let total = expenses.reduce((sum, exp) => sum + parseFloat(exp.amount), 0);
    totalAmountDisplay.textContent = total.toFixed(2);
}

document.addEventListener("DOMContentLoaded", function () {
    const dateInput = document.querySelector("input[type='date']");

    dateInput.addEventListener("focus", function () {
        this.showPicker(); // Automatically opens the date picker
    });
});

// addButton.addEventListener("keypress", function(event) {
//     if (event.key === "Enter") {
//         addTask();
//     }
// });